# Build

It is recommended that you build the program in the build folder.
To build:

bash```
cd build
make
```

# Running

## With numbers generated in place

From the build directory:

bash```
sbatch -n 16 Parallel.sh 12 1
```

### Program / Script Parameters
[ Script or Program name ] [ n: size of one dimension of a nxn matrix ] [ save code: 1 to save, anything else to not save]


## With files for matrix A and B

From the build directory:

bash```
sbatch -n 16 Parallel.sh matA.txt matB.txt 1
```

### Program / Script Parameters
[ Script or Program name ] [ file for mat A ] [ file for mat B ] [ save code: 1 to save, anything else to not save]

